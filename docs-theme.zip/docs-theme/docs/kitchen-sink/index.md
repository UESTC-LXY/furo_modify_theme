# Kitchen Sink

This section exists as a dump of "all sorts of edge cases" in Furo's styling.
It is built upon an excellent base provided by Sphinx-RTD-Theme, as written by the amazing folks at ReadTheDocs.

The goal is to ensure that we're adding more content here that looks good, without breaking anything externally. :)

```{toctree}
:titlesonly:

demo
lists_tables
really-long
structure
```
